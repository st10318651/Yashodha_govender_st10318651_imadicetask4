package com.yashodha.imadicetask4

import android.animation.ObjectAnimator
import android.os.Bundle
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.widget.Button
import android.widget.TextView
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var questionTextView: TextView
    private lateinit var option1Button: Button
    private lateinit var option2Button: Button
    private lateinit var returnButton: Button
    private lateinit var scoreTextView: TextView
    private lateinit var animationView: ImageView

    // Define the Question data class
    data class Question(val question: String, val options: List<String>, val correctOption: Int)

    private val questions = listOf(

        Question("What is the capital of France?", listOf("Paris", "London"), 1),
        Question("Which planet is known as the Red Planet?", listOf("Venus", "Mars"), 2),
        Question("How many continents are there in the world?", listOf("6", "7"), 2),
        Question("What is the largest mammal on Earth?", listOf("Elephant", "Blue Whale"), 2),
        Question("Who wrote the play 'Romeo and Juliet'?", listOf("William Shakespeare", "Charles Dickens"), 1),

    )

    private var currentQuestionIndex = 0
    private var score = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        questionTextView = findViewById(R.id.QuestionTextView)
        option1Button = findViewById(R.id.option1Button)
        option2Button = findViewById(R.id.option2button)
        returnButton = findViewById(R.id.returnButton)
        scoreTextView = findViewById(R.id.scoreTextView)
        animationView = findViewById(R.id.animationView)

        option1Button.setOnClickListener { checkAnswer(1) }
        option2Button.setOnClickListener { checkAnswer(2) }
        returnButton.setOnClickListener { handleReturnButton() }

        showNextQuestion()
    }

    private fun showNextQuestion() {
        if (currentQuestionIndex < questions.size) {
            val question = questions[currentQuestionIndex]
            questionTextView.text = question.question
            option1Button.text = question.options[0]
            option2Button.text = question.options[1]
        } else {
            // All questions answered
            scoreTextView.text = "Score: $score"
            val animationDrawableId = if (score < 3) R.drawable.sadface else R.drawable.balloons

            // Use setImageResource to replace the existing image
            animationView.setImageResource(animationDrawableId)

            // Rotation animation
            val animator = ObjectAnimator.ofFloat(animationView, "rotationY", 0f, 360f)
            animator.interpolator = AccelerateInterpolator()
            animator.duration = 2000
            animator.start()

            return
        }
        currentQuestionIndex++
    }

    private fun checkAnswer(selectedOption: Int) {
        if (currentQuestionIndex <= questions.size) {
            val question = questions[currentQuestionIndex - 1]
            if (question.correctOption == selectedOption) {
                score++
            }
            showNextQuestion()
            updateScore()
        }
    }

    private fun updateScore() {
        scoreTextView.text = "Score: $score"
    }

    private fun handleReturnButton() {
        // Handle the return button action here, e.g., going back to the main menu or resetting the quiz.
    }
}


